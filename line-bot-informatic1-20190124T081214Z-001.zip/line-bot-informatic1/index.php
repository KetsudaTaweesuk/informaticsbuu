<?php
echo "Hello LINE BOT \"Informatics @BUU\"";
